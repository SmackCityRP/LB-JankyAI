-- client/client.lua
-- This script registers the JankyAI app with the LB Tablet and manages the API key.

local Config = {
    AppName = "JankyAI",
    Description = "A chat interface for a conversational AI.",
    DefaultApp = false,
    Size = 2500,
    Images = {}
}

-- THE API KEY GOES HERE --
-- Replace "YOUR_GEMINI_API_KEY_HERE" with your actual Gemini API key.
local API_KEY = "YOUR_GEMINI_API_KEY_HERE"

-- The unique identifier for your app.
local identifier = "jankyai-app"

CreateThread(function ()
    -- Wait until the lb-tablet resource has started before registering the app.
    while GetResourceState("lb-tablet") ~= "started" do
        Wait(500)
    end

    local function AddApp()
        -- Use the AddCustomApp export to register the app.
        local added, errorMessage = exports["lb-tablet"]:AddCustomApp({
            identifier = identifier,
            name = Config.AppName,
            description = Config.Description,
            developer = "2xJanky",
            defaultApp = Config.DefaultApp,
            size = Config.Size,
            images = Config.Images,
            ui = "html/index.html", -- The path to the main HTML file
            icon = "https://cfx-nui-" .. GetCurrentResourceName() .. "/html/assets/app.jpg"
        })

        if not added then
            print("Could not add app:", errorMessage)
        end
    end

    -- Call the function to add the app on resource start.
    AddApp()

    -- Add a failsafe in case lb-tablet starts after this resource.
    AddEventHandler("onResourceStart", function(resource)
        if resource == "lb-tablet" then
            AddApp()
        end
    end)
    
    -- Register a callback to send the API key to the NUI when requested.
    -- The key is kept server-side and only sent to the client when the app is running.
    RegisterNUICallback("getApiKey", function(data, cb)
        if API_KEY ~= "YOUR_GEMINI_API_KEY_HERE" and API_KEY ~= "" then
            cb({success = true, key = API_KEY})
        else
            cb({success = false, message = "API key not configured."})
        end
    end)
end)
