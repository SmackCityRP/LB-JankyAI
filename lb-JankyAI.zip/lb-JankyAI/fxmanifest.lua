fx_version 'cerulean'
game 'gta5'

author '2xJanky'
description 'A chat interface for a conversational AI.'
version '1.0.0'

files {
    'html/index.html',
    'html/assets/app.jpg' 
}

client_scripts {
    'client/client.lua'
}
