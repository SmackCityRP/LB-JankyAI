JankyAI - A Simple fivem AI Chat Resource
JankyAI is a lightweight fivem resource that allows players to chat with a Gemini-powered AI assistant directly through a tablet-style NUI. It provides a simple, clean, and responsive user interface for conversational AI.


To use this resource, you will need:

A running fivem server.

A Gemini API key. You can get one for free at ai.google.dev.

Installation
Place the janky-ai folder into your server's resources directory.

Configure your API Key:

Open the client.lua file inside the janky-ai folder.

Find the line:

local API_KEY = "YOUR_GEMINI_API_KEY_HERE"

Replace "YOUR_GEMINI_API_KEY_HERE" with your actual API key.

Add to server.cfg:

Add the following line to your server.cfg file to ensure the resource starts automatically:

ensure janky-ai

Usage
Once the resource is running, players use the app in the lb-tablet:


This will display a tablet with the chat interface. Simply type your message in the input box and press "Send" to get a response from the AI.

Troubleshooting
API Key Not Working: If the chat interface displays an error about the API key, double-check that you have entered it correctly in client.lua. Ensure there are no extra spaces or characters.

Resource Not Starting: Make sure you've added ensure janky-ai to your server.cfg and that the folder is named exactly janky-ai.

No Response: If the AI doesn't respond, check your server console for any errors related to the janky-ai resource. This could indicate a network issue or an invalid API key.